#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 25 21:32:40 2019

@author: Georgia Tech, ISyE, Instructor Yao Xie 
"""
import numpy as np
import math
import matplotlib.pyplot as plt
import scipy.io as spio
import scipy.sparse.linalg as ll
import sklearn.preprocessing as skpp
import pandas as pd

# show image function
def show_image(centroids,H,W=None):
    if W == None: W = H
    N = centroids.shape[1]/(H*W)
    assert N == 3 or N == 1 # color and grey images
    K = centroids.shape[0]
    COLS = round(math.sqrt(K))
    ROWS = math.ceil(K/COLS)
    N = int(N)
    image = np.ones((ROWS*(H+1), COLS*(W+1), N))*100
    for i in range(centroids.shape[0]):
        r = math.floor(i / COLS)
        c = (i-1) % COLS
        image[(r*(H+1)+1):((r+1)*(H+1)),(c*(W+1)+1):((c+1)*(W+1)),:] = centroids[i,:W*H*N+1].reshape((H,W,N))
    plt.imshow(image[:,:,0])
    plt.show()
    
#%%
##########################
# PCA_leaf main function #
##########################
    
leaf = pd.read_csv('data/food-consumption.csv')

# dataset description
#The provided data comprises the following shape (attributes 3 to 9) and texture (attributes 10
#to 16) features:
#1. Class (Species)
#2. Specimen Number
#3. Eccentricity
#4. Aspect Ratio
#5. Elongation
#6. Solidity
#7. Stochastic Convexity
#8. Isoperimetric Factor
#9. Maximal Indentation Depth
#10. Lobedness
#11. Average Intensity
#12. Average Contrast
#13. Smoothness
#14. Third moment
#15. Uniformity
#16. Entropy

# extract attributes from raw data
Anew = leaf.iloc[:, 1:]

m,n = Anew.shape

# create indicator matrix
Inew = leaf.iloc[:,0] 
Inew = pd.factorize(leaf['Country'])
names = leaf['Country']
Inew = Inew[0]


# In this case, we normalize the data because features have very different ranges
stdA = np.std(Anew,axis = 0)
Anew = Anew @ np.diag(np.ones(stdA.shape[0])/stdA)
Anew = Anew.T
# PCA
mu = np.mean(Anew,axis = 1)
xc = Anew - mu[:,None]

C = np.dot(xc,xc.T)/m

K = 2
S,W = ll.eigs(C,k = K)
S = S.real
W = W.real

dim1 = np.dot(W[:,0].T,xc)/math.sqrt(S[0]) # extract 1st eigenvalues
dim2 = np.dot(W[:,1].T,xc)/math.sqrt(S[1]) # extract 2nd eigenvalue

color_string = 'bgrmck'
marker_string = '.+*o'
leaf_fig = plt.figure()
print(names)
for i in range(int(max(Inew))):
    print(names[i])
    color = color_string[i % 5]
    marker = marker_string[i % 4]
    m = color + marker
    leaf_fig.gca().plot(dim1[Inew == i],dim2[Inew == i],m)
    leaf_fig.gca().annotate(names[i], (dim1[Inew == i],dim2[Inew == i]), textcoords="offset points", xytext=(0,10), ha='center')

plt.show()
leaf_fig.savefig('images/countries_1.png')



#Now flip it so food are the features
# extract attributes from raw data
# Remove the first column
data = leaf.iloc[:, 1:]

# Transpose the data
dataT = data.transpose()
Anew = dataT.iloc[:, 1:]
m,n = Anew.shape

# create indicator matrix
Inew = dataT.iloc[:,0] 
Inew = pd.factorize( dataT.iloc[:, 0])
names = data.columns
Inew = Inew[0]


# In this case, we normalize the data because features have very different ranges
stdA = np.std(Anew,axis = 0)
Anew = Anew @ np.diag(np.ones(stdA.shape[0])/stdA)
Anew = Anew.T
# PCA
mu = np.mean(Anew,axis = 1)

xc = Anew - mu[:,None]

C = np.dot(xc,xc.T)/m

K = 2
S,W = ll.eigs(C,k = K)
S = S.real
W = W.real

dim1 = np.dot(W[:,0].T,xc)/math.sqrt(S[0]) # extract 1st eigenvalues
dim2 = np.dot(W[:,1].T,xc)/math.sqrt(S[1]) # extract 2nd eigenvalue

color_string = 'bgrmck'
marker_string = '.+*o'
leaf_fig = plt.figure()
for i in range(int(max(Inew))):
    print(names[i])
    color = color_string[i % 5]
    marker = marker_string[i % 4]
    m = color + marker
    leaf_fig.gca().plot(dim1[Inew == i],dim2[Inew == i],m)
    leaf_fig.gca().annotate(names[i], (dim1[Inew == i][0],dim2[Inew == i][0]), textcoords="offset points", xytext=(0,10), ha='center')

plt.show()
leaf_fig.savefig('images/countries_2.png')
