import numpy as np
from sklearn.metrics import pairwise_distances
import scipy.sparse.linalg as ll
import networkx as nx
import matplotlib.pyplot as plt
import scipy.io as spio
from scipy.sparse.csgraph import shortest_path
import math
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
import os
from PIL import Image
from sklearn.decomposition import PCA

images = []
or_images = []
for filename in os.listdir('data/yalefaces/'):
    if filename != 'subject01-test.gif' and filename != 'subject02-test.gif':
        file_path = os.path.join('data/yalefaces/', filename)
        with Image.open(file_path) as img:
            img = img.convert("L")
            o_img = img.resize((12, 12), Image.Resampling.LANCZOS)
            img_array = np.array(img).flatten()
            # Get every 4th value
            img_array = img_array[::3]
            images.append(img_array)
            or_images.append(o_img)

data = np.vstack(images)
data = data.T

#Get local euclidian distances
locals = pairwise_distances(data, metric='euclidean')

pic_num = 19
A = np.zeros((pic_num, pic_num), dtype=int)
epsilon = [800]
for e in epsilon:
    for i in range(pic_num):
        for j in range(i + 1, pic_num):
            distance = np.linalg.norm(locals[i] - locals[j])
            if locals[i][j] <= e:
                A[i][j] = distance
                A[j][i] = distance


#PCA
Anew = A
m,n = Anew.shape
Inew = np.arange(pic_num)
stdA = np.std(Anew,axis = 0)
Anew = Anew @ np.diag(np.ones(stdA.shape[0])/stdA)
Anew = Anew.T

# PCA
mu = np.mean(Anew,axis = 1)
xc = Anew - mu[:,None]
C = np.dot(xc,xc.T)/m
K = 5
C = np.nan_to_num(C,  nan=0)
S,W = ll.eigs(C,k = K)
S = S.real
W = W.real

dim1 = np.dot(W[:,0].T,xc)/math.sqrt(S[0]) # extract 1st eigenvalues
dim2 = np.dot(W[:,1].T,xc)/math.sqrt(S[1]) # extract 2nd eigenvalue

#plot
plot,sub  = plt.subplots(figsize=(6, 6))

#add points
sub.scatter(dim1,dim2)
for i in range(6):
    sub.scatter(dim1,dim2)
    pic = or_images[i]
    picture_box = AnnotationBbox(OffsetImage(pic,zoom=2.5), (dim1[i],dim2[i]), pad = .2)
    sub.add_artist(picture_box)

plot.savefig('images/yf_one.png')



images = []
or_images = []
for filename in os.listdir('data/yalefaces/'):
    if filename == 'subject01-test.gif' or filename == 'subject02-test.gif':
        file_path = os.path.join('data/yalefaces/', filename)
        with Image.open(file_path) as img:
            img = img.convert("L")
            o_img = img.resize((12, 12), Image.Resampling.LANCZOS)
            img_array = np.array(img).flatten()
            img_array = img_array[::3]
            images.append(img_array)
            or_images.append(o_img)

data = np.vstack(images)
data = data.T

vals = []
avgs = []
for k in range(4):
    sum = 0
    for f in range(len(data)):
        sum = sum + data[f]
    avgs = sum/len(data)
print(avgs)
for i in range(2):
    for j in range(2):
        value = avgs[i] - avgs[j] * W[j][1] * (W[i][1].T)
        vals.append(value)


print('Projection Residuals:')
print(vals)

