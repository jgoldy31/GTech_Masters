import numpy as np
from sklearn.metrics import pairwise_distances
import scipy.sparse.linalg as ll
import networkx as nx
import matplotlib.pyplot as plt
import scipy.io as spio
from scipy.sparse.csgraph import shortest_path
import math
from matplotlib.offsetbox import OffsetImage, AnnotationBbox


load_data = spio.loadmat('data/isomap.mat')
data = load_data['images']
data = data.T
print(load_data['images'])
#Get local euclidian distances
locals = pairwise_distances(data, metric='euclidean')

pic_num = 698
A = np.zeros((pic_num, pic_num), dtype=int)
B = np.zeros((pic_num,pic_num), dtype=int)
epsilon = [6,9,12,15]
for e in epsilon:
    for i in range(pic_num):
        for j in range(i + 1, pic_num):
            distance = np.linalg.norm(locals[i] - locals[j])
            if locals[i][j] <= e:
                A[i][j] = distance
                A[j][i] = distance
    plt.spy(A)
    plt.title('Adjacency Matrix')
    plt.savefig('images/a_matrix' + str(e) + '.png')

#Get shortest path
D = shortest_path(A)

#use algorithm provided to compute G - lecture
empty = np.ones(shape = (698))
H = np.identity(locals.shape[0]) - (1/locals.shape[0]) * np.outer(empty, empty)

# Get G
Dsq = np.square(D)
G = (-1/2) * np.dot(np.dot(H, Dsq), H)


#Get eigenvals
K = 100
S,W = ll.eigs(G,k = K)
S = S.real
W = W.real
dim1 = np.dot(W[:,0].T,A)/math.sqrt(S[0]) # extract 1st eigenvalues
dim2 = np.dot(W[:,1].T,A)/math.sqrt(S[1]) # extract 2nd eigenvalue



#plot
plot,sub  = plt.subplots(figsize=(6, 6))
#add points
sub.scatter(dim1,dim2)

#add photos
#https://stackoverflow.com/questions/22566284/matplotlib-how-to-plot-images-instead-of-points
#https://matplotlib.org/stable/api/offsetbox_api.html
for i in range(150):
    sub.scatter(dim1,dim2)
    #reshape to form original images
    pic = data[i,:].reshape(64, 64).T

    picture_box = AnnotationBbox(OffsetImage(pic,zoom=0.3), (dim1[i],dim2[i]), pad = .2)
    sub.add_artist(picture_box)
    

plot.savefig('images/isomap.png')


#PCA
# extract attributes from raw data
Anew = A

m,n = Anew.shape

# create indicator matrix
Inew = np.arange(699)


# In this case, we normalize the data because features have very different ranges
stdA = np.std(Anew,axis = 0)
Anew = Anew @ np.diag(np.ones(stdA.shape[0])/stdA)
Anew = Anew.T
# PCA
mu = np.mean(Anew,axis = 1)
xc = Anew - mu[:,None]
C = np.dot(xc,xc.T)/m
K = 2
S,W = ll.eigs(C,k = K)
S = S.real
W = W.real

dim1 = np.dot(W[:,0].T,xc)/math.sqrt(S[0]) # extract 1st eigenvalues
dim2 = np.dot(W[:,1].T,xc)/math.sqrt(S[1]) # extract 2nd eigenvalue

for i in range(150):
    sub.scatter(dim1,dim2)
    #reshape to form original images
    pic = data[i,:].reshape(64, 64).T

    picture_box = AnnotationBbox(OffsetImage(pic,zoom=0.3), (dim1[i],dim2[i]), pad = .2)
    sub.add_artist(picture_box)

plot.savefig('images/pca.png')